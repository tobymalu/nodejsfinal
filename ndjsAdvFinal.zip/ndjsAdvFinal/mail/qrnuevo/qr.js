const express= require('express')
const qr= require('qrcode')

const app= express()
const PORT =3000

app.get("/getQR", (req, res)=>{
    const dataUrl= 'https://vallartamagico.com.mx/'
    const options ={
        errorCorrectionLevel: "H",
        type:'image/jpeg',
        renderOpts:{
            quality: 0.5
        }
    }
    qr.toDataURL(dataUrl, options, (err, qrImg)=>{
        if (err){
            console.error("error al general el codigo", err)
            res.status(500).json({error:"error al general el codigo"})
        } else{
            res.setHeader('content-Type', 'text/html')

            res.send(`
               <html>
                 <head>
                   <title>Qr Generator</title>
                 </head>
                 <body>
                   <h1> Qr code generador</h1>
                   <img alt="aqui esta un codigo Qr" src="${qrImg}" />
                 </body>
               </html>
            `)
        }
    })
})
app.listen(3000, ()=>{
    console.log('Servidor en puerto 3000');
})