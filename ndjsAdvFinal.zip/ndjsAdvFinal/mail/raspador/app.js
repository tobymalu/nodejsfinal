const cheerio= require('cheerio')
const axios= require('axios')

const url = "https://vallartamagico.com.mx/";

axios.get(url)
  .then((response) => {
    if (response.status === 200) {
      const $ = cheerio.load(response.data);

      const links = [];

      $('h4').each((index, element) => {
        const linkText = $(element).text();
        links.push({ text: linkText });
      });

      console.log("Elementos encontrados:");
      links.forEach((link, index) => {
        console.log(`${index + 1}. Text: ${link.text}`);
      });
    }
  })
  .catch((err) => {
    console.error("Error al conectarse a la página:", err.message);
  });