const express = require('express');
const app = express();
const path = require ('path');
//creamos servidor y path ayuda a organizar carpetas//

app.use(express.urlencoded({extended: false})); //3 el Servido entiene lo que recibe//

app.use(require('./routes/index')); //2 usamos la ruta que generamos//

app.use(express.static(path.join(__dirname, 'public'))); //Aqui le decimos que aqui esta la carpeta publica del servidor//

app.listen(3000, ()=>{
    console.log('Servidor en puerto 3000');
})
