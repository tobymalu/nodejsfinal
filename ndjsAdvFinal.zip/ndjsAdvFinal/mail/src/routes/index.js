const { Router } = require('express'); //1 importamos la funcion router de expres//
const nodemailer= require('nodemailer'); //8 instalamos nodemailer
const router = Router();

router.post('/enviar', async (req, res)=>{
   //4 console.log(req.body); utilice esto para ver que recibiera la informacion//
   const {nombre, correo, telefono, mensaje} = req.body;    //5 es para solicitar los datos mas sencillo// 
   //6 hacemos la estructura del correo como lo queremos recibir//
   contentHTML=`
    <h1>Un nuevo Lead<h1>
     <ul> 
      <li>nuevoRegistro: ${nombre}</li>
      <li>Correo:${correo}</li>
      <li>Telefono: ${telefono}</li>
     </ul>
     <p>${mensaje}</p>
   `;
   //7 console.log(contentHTML) vemos que si salga la estructura//
   const transport = nodemailer.createTransport({
    host: "smtp-mail.outlook.com",
    port: 587,
    auth: {
      user: "joaquin.villanuevam@hotmail.com",
      pass: "tobymalu0788"
    }
  }); //9 datos contra para envio mail//

   const info= await transport.sendMail({
    from: "'Datos en web' <joaquin.villanuevam@hotmail.com>",
    to: 'joaquin_junior@hotmail.com',
    subject: 'Dato de nuevo lead',
    html: contentHTML
   })//10 envio el contenido optenido a mi correo para agregar mas leads//
   console.log('Mensaje enviado', info.messageId);
    res.redirect('/correcto.html')
})

module.exports = router;